<?php
/**
 * Patch: Insert TV and AC devices into the database
 * Visit:  http://localhost/IOT/backend_php/patch_devices.php
 * DELETE this file after running!
 */

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'iot_home';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER, $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Also fix devices table ENUM to allow 'tv' and 'ac' types
    // (older schema only allowed light/fan/switch/sensor — switch covers both)

    $newDevices = [
        ['tv', 'Smart TV',        'switch', 18, 'home/tv/set',  'home/tv/status'],
        ['ac', 'Air Conditioner', 'switch', 21, 'home/ac/set',  'home/ac/status'],
    ];

    $results = [];
    foreach ($newDevices as $d) {
        // Check if already exists
        $chk = $pdo->prepare("SELECT id, device_name FROM devices WHERE device_key = ?");
        $chk->execute([$d[0]]);
        $row = $chk->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // Already exists — make sure it's active
            $upd = $pdo->prepare("UPDATE devices SET is_active = 1, device_name = ?, topic_set = ?, topic_status = ? WHERE device_key = ?");
            $upd->execute([$d[1], $d[4], $d[5], $d[0]]);
            $results[] = ['ok', "✅ '{$d[0]}' already in DB — ensured active (id={$row['id']})"];
        } else {
            $ins = $pdo->prepare(
                "INSERT INTO devices (device_key, device_name, device_type, gpio_pin, topic_set, topic_status, current_state, is_active)
                 VALUES (?, ?, ?, ?, ?, ?, 'OFF', 1)"
            );
            $ins->execute($d);
            $results[] = ['ok', "✅ '{$d[0]}' inserted successfully (id=" . $pdo->lastInsertId() . ")"];
        }
    }

    // Show all current devices
    $all = $pdo->query("SELECT device_key, device_name, device_type, current_state, is_active FROM devices ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $results[] = ['err', "❌ DB Error: " . $e->getMessage()];
    $all = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <title>Device Patch</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Segoe UI',sans-serif;background:#060b18;color:#e8eaf6;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
    .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:40px;max-width:600px;width:100%}
    h1{font-size:20px;margin-bottom:20px}
    .item{padding:10px 16px;border-radius:10px;margin-bottom:8px;font-size:14px}
    .ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.25);color:#86efac}
    .err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#fca5a5}
    table{width:100%;border-collapse:collapse;margin-top:24px;font-size:13px}
    th,td{padding:10px 14px;text-align:left;border-bottom:1px solid rgba(255,255,255,.07)}
    th{color:#93c5fd;font-weight:600}
    .on{color:#86efac}.off{color:#fca5a5}
    .btn{display:inline-block;margin-top:20px;padding:12px 28px;background:linear-gradient(135deg,#4f8ef7,#7c5cfc);border-radius:10px;color:#fff;text-decoration:none;font-weight:600;font-size:14px}
    .warn{margin-top:16px;padding:12px 16px;background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.25);border-radius:10px;font-size:12px;color:#fcd34d}
  </style>
</head>
<body>
<div class="card">
  <h1>🔧 Device DB Patch</h1>
  <?php foreach ($results as [$cls, $msg]): ?>
    <div class="item <?= $cls ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endforeach; ?>

  <?php if (!empty($all)): ?>
  <table>
    <thead><tr><th>Key</th><th>Name</th><th>Type</th><th>State</th><th>Active</th></tr></thead>
    <tbody>
    <?php foreach ($all as $dev): ?>
      <tr>
        <td><b><?= htmlspecialchars($dev['device_key']) ?></b></td>
        <td><?= htmlspecialchars($dev['device_name']) ?></td>
        <td><?= htmlspecialchars($dev['device_type']) ?></td>
        <td class="<?= $dev['current_state']==='ON'?'on':'off' ?>"><?= $dev['current_state'] ?></td>
        <td><?= $dev['is_active'] ? '✅' : '❌' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <a class="btn" href="../frontend/dashboard.html">Go to Dashboard →</a>
  <div class="warn">⚠️ Delete <code>backend_php/patch_devices.php</code> after running!</div>
</div>
</body>
</html>
